#include<unistd.h>
#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include "quiz.h"

extern int play(quiz_t *quiz){
	//reinitialize status for new question
	int answer,check;
	unsigned int points = 8;
	quiz->max = quiz->max + 8;
	//fetch and parse question including error handling
	if((parse(fetch("http://numbersapi.com/random/math?min=1&max=100&fragment&json"),quiz)) == 0){return 0;}
	printf("Q%d: What is %s?\n",quiz->n,quiz->text);
	//prompt for answer with maximum 4 mistakes
	for(int i = 0; i<4;i++){
		printf("%u pt> ",points);
		check = scanf("%d",&answer);
		if(!check){printf("Invalid input, try again.\n");continue;} //malicious input handling
		if(answer == quiz->number){
			quiz->score = quiz->score + points;
			printf("Congratulation, your answer %d is correct\n",answer);
		}
		else {
			//wrong answer handling
			points = points/2;
			if(answer < quiz->number){printf("Too small, try again.\n");}
			else if(answer > quiz->number){printf("Too large, try again.\n");}
		}
	}
	printf("Your total score is %u/%u points.\n",quiz->score,quiz->max);
	return 1;
}