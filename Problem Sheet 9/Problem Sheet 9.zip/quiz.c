#include<unistd.h>
#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<signal.h>
#include "quiz.h"

void intHandler(int intnum);
int end_quiz(quiz_t *quiz);

static volatile int run = 1;
quiz_t quiz = {0, 0, 0, NULL, -1};

int main(int argc, char *argv[])
{
	signal(SIGINT, intHandler);
	int player;

	printf("Answer questions with numbers in the range [1..100].\nYou score points for each correctly answered question.\nIf you need multiple attempts to answer a question, the points you score for a correct answer go down.");
	
	while (run) // while loop that terminates when variable run status changes
	{
		quiz.n++;
		player = play(&quiz);
		if (player == -1) {break; }
		if (player == 0) {
			printf("****ERROR:fetch or parse \nTERMINATING..\n");
			return 0;
		}
		printf("\n");
	}
	end_quiz(&quiz);

	return 0;
}
/*
* Signal function that is used change the state of run when CTRL-C or CTRL-D is pressed
*/
void intHandler(int intnum){
	run = 0;
}

/*
* Ends the quiz process and announces the final score to the player
*/
int end_quiz(quiz_t *quiz)
{
	printf("Your total score is %u/%u points. \n", quiz->score, quiz->max);
	printf("\nThanks for playing today.\nYour final score is %u/%u points.\n", quiz->score,quiz->max);

	return 0;
}