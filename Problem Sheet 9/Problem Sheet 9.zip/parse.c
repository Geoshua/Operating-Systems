#include<stdio.h>
#include<json-c/json.h>
#include "quiz.h"

extern int parse(char *json, quiz_t *quiz)
{
	struct json_object *new_json,*text,*num;
	new_json = json_tokener_parse(json);
	
	if(new_json == NULL){//error handling for is initial parse fails
		perror("****ERROR:parsing json failed\n");
		return 0;
	}
	else{
		json_object_object_get_ex(new_json,"text", &text);
		json_object_object_get_ex(new_json,"number", &num);
		//filling the next question for quiz
		quiz->text = json_object_to_json_string(text);
		quiz->number = json_object_get_int(num);
		//DEBUG
		printf("DEBUG text: %s\n ",json_object_get_string(text));
		printf("DEBUG num: %d\n",json_object_get_int(num));
		return 1;
	}
}